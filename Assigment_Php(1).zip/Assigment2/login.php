<html>
<head>
<title>Login</title>
</head>
<body>
<h1>Login</h1>
    <form method="post" action="#">
    	<input type="text" name="txt_user" placeholder="Username" required /></br>
        <input type="password" name="txt_pwd" placeholder="Password" required />
        </br>
        <hr />
        <button type="submit">Login</button>
    </form> 
</body>
</html>
<?php
session_start();
if(isset($_POST["txt_pwd"]))
{
	
	if ($_POST["txt_pwd"]=="shehara123"&& $_POST["txt_user"]=="shehara"){
    	
		$_SESSION['Last_Time']=time();
		header("Location:Home.php");
		exit();
	} else {
		echo '<script language="javascript">';
		echo' alert("Invalid UserName Or Password")';
		echo '</script>';
	
	}
}




?>